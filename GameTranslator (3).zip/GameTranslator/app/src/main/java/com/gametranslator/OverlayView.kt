package com.gametranslator

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

data class Item(val src: String, val box: Rect, var ar: String? = null, val region: Int = 0)

/**
 * Full-screen, non-touchable layer. Two display modes:
 *  - subtitle bar: one clean panel with the translation (does not cover the game text)
 *  - in-place boxes: Arabic boxes painted over each original text block
 */
class OverlayView(ctx: Context, var k: Float) : View(ctx) {
    private var items: List<Item> = emptyList()
    private var sub: String = ""
    private var barLayout: StaticLayout? = null
    var subAtTop = true

    /** 1.0 = normal. Bigger = larger Arabic text (boxes grow to fit). */
    var fontScale = 1.3f

    /** Where the subtitle bar sits on screen (screen px); read by the service to mask it from OCR. */
    @Volatile var bar: RectF? = null

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF101018.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = 0xFFF8F8F8.toInt()
        typeface = Typeface.create(Typeface.DEFAULT, 600, false)   // medium-bold, smoother than full bold
        setShadowLayer(3f, 0f, 1.5f, 0x99000000.toInt())
    }

    fun setItems(l: List<Item>) { items = l; invalidate() }

    fun setSubtitle(t: String) { sub = t; layoutBar(); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutBar()
    }

    private fun layoutBar() {
        if (sub.isBlank() || width == 0 || height == 0) { barLayout = null; bar = null; return }
        val maxW = (width * 0.8f).toInt()
        var size = height * 0.045f * fontScale
        var l: StaticLayout
        while (true) {
            tp.textSize = size
            l = StaticLayout.Builder.obtain(sub, 0, sub.length, tp, maxW - 48)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.1f)
                .build()
            if (l.height <= height * 0.4f || size <= 20f) break
            size -= 2f
        }
        barLayout = l
        val bw = maxW.toFloat()
        val bh = l.height + 40f
        val left = (width - bw) / 2f
        val top = if (subAtTop) height * 0.03f else height - bh - height * 0.03f
        bar = RectF(left, top, left + bw, top + bh)
    }

    override fun onDraw(c: Canvas) {
        val b = bar
        val bl = barLayout
        if (b != null && bl != null) {
            c.drawRoundRect(b, 22f, 22f, bg)
            c.save()
            c.translate(b.left + 24f, b.top + 20f)
            bl.draw(c)
            c.restore()
        }
        for (item in items) {
            val ar = item.ar ?: continue
            val r = RectF(item.box.left * k, item.box.top * k, item.box.right * k, item.box.bottom * k)
            // text wraps in a column a bit wider than the original; the box grows to fit it
            val colW = (r.width() * 1.25f).coerceIn(240f, width * 0.9f)
            var size = (r.height() * 0.8f).coerceIn(30f, 60f) * fontScale
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(ar, 0, ar.length, tp, colW.toInt())
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 1.1f)
                    .build()
                if (layout.height <= max(r.height() * 2.2f, 100f) || size <= 22f) break
                size -= 2f
            }
            val bw = colW + 28f
            val bh = layout.height + 20f
            val cx = r.centerX().coerceIn(bw / 2f, max(width - bw / 2f, bw / 2f))
            val cy = r.centerY().coerceIn(bh / 2f, max(height - bh / 2f, bh / 2f))
            val box = RectF(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f)
            c.drawRoundRect(box, 16f, 16f, bg)
            c.save()
            c.translate(box.left + 14f, box.top + 10f)
            layout.draw(c)
            c.restore()
        }
    }
}
