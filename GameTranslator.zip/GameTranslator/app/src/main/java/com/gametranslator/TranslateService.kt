package com.gametranslator

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.View
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TranslateService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainH = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var thread: HandlerThread? = null
    private lateinit var wm: WindowManager
    private lateinit var recognizer: TextRecognizer
    private lateinit var translator: Translator
    private lateinit var dao: TrDao
    @Volatile private var frame: Bitmap? = null
    @Volatile private var frameSeq = 0L
    private var scale = 1f
    private var game = "global"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        start(intent.getIntExtra("code", 0), data)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("gt", "Game Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "gt")
            .setContentTitle("مترجم الألعاب شغال")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun start(code: Int, data: Intent) {
        val prefs = getSharedPreferences("gt", MODE_PRIVATE)
        val lang = prefs.getString("lang", "en") ?: "en"
        translator = Translator(lang, prefs.getString("key", "") ?: "")
        recognizer = when (lang) {
            "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        dao = AppDb.get(this).dao()
        wm = getSystemService(WindowManager::class.java)

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, mainH)

        thread = HandlerThread("gt-capture").also { it.start() }
        val (sw, sh) = screenSize()
        buildCapture(sw, sh)

        overlay = OverlayView(this, 1f / scale)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(overlay, lp)

        scope.launch { loop() }
    }

    private var capW = 0
    private var capH = 0

    private fun screenSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return b.width() to b.height()
    }

    // Builds (or rebuilds after rotation) the capture surface at the current screen size.
    private fun buildCapture(sw: Int, sh: Int) {
        scale = min(1f, 1400f / max(sw, sh))
        val cw = (sw * scale).toInt()
        val ch = (sh * scale).toInt()
        capW = cw
        capH = ch
        val old = reader
        val nr = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        nr.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try { frame = toBitmap(img, cw, ch); frameSeq++ } finally { img.close() }
            }
        }, Handler(thread!!.looper))
        reader = nr
        val dpi = resources.displayMetrics.densityDpi
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "gt", cw, ch, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nr.surface, null, null
            )
        } else {
            display!!.resize(cw, ch, dpi)
            display!!.surface = nr.surface
        }
        old?.close()
        frame = null
        overlay?.k = 1f / scale
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val bmp = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, w, h)
    }

    // Coarse luminance grid: tells us if the screen really changed.
    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(24 * 40)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(a.size) { (Color.red(a[it]) * 3 + Color.green(a[it]) * 6 + Color.blue(a[it])) / 10 }
    }

    private fun changed(a: IntArray, b: IntArray): Boolean {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return d / a.size > 4
    }

    private suspend fun loop() {
        var last: IntArray? = null
        var lastWork = 0L
        while (currentCoroutineContext().isActive) {
            delay(600)
            val (sw, sh) = screenSize()
            if ((sw * scale).toInt() != capW || (sh * scale).toInt() != capH) {
                // screen rotated (portrait <-> landscape): rebuild capture
                buildCapture(sw, sh)
                last = null
                continue
            }
            val f = frame ?: continue
            val s = sig(f)
            val prev = last
            if (prev != null && !changed(s, prev)) continue
            if (System.currentTimeMillis() - lastWork < 1200) continue
            lastWork = System.currentTimeMillis()

            // Hide our own boxes for a moment so OCR sees the real game text.
            val seq = frameSeq
            withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE }
            val t0 = System.currentTimeMillis()
            while (frameSeq == seq && System.currentTimeMillis() - t0 < 500) delay(30)
            val shot = frame?.copy(Bitmap.Config.ARGB_8888, false)
            withContext(Dispatchers.Main) {
                overlay?.setItems(emptyList())
                overlay?.visibility = View.VISIBLE
            }
            if (shot != null) {
                try { process(shot) } catch (_: Exception) { }
            }
            delay(250)
            last = frame?.let { sig(it) }
        }
    }

    private suspend fun process(shot: Bitmap) {
        updateGame()
        val res = recognizer.process(InputImage.fromBitmap(shot, 0)).await()
        val items = res.textBlocks.mapNotNull { b ->
            val box = b.boundingBox ?: return@mapNotNull null
            val t = b.text.replace('\n', ' ').trim()
            if (worth(t)) Item(t, box) else null
        }
        if (items.isEmpty()) return

        // 1) Cache first: known texts appear instantly, no API/translation call.
        val cached = dao.get(items.map { id(it.src) }).associateBy { it.id }
        items.forEach { cached[id(it.src)]?.let { e -> it.ar = e.ar } }
        show(items)

        // 2) Translate only what's new, then store it for next time.
        val missing = items.filter { it.ar == null }.distinctBy { id(it.src) }
        if (missing.isNotEmpty()) {
            val out = translator.translate(missing.map { it.src })
            val rows = missing.mapIndexedNotNull { i, m ->
                out.getOrNull(i)?.let { TrEntry(id(m.src), game, m.src, it) }
            }
            if (rows.isNotEmpty()) dao.put(rows)
            val map = rows.associateBy { it.id }
            items.forEach { if (it.ar == null) it.ar = map[id(it.src)]?.ar }
            show(items)
        }
    }

    private suspend fun show(items: List<Item>) =
        withContext(Dispatchers.Main) { overlay?.setItems(items.toList()) }

    private fun id(t: String) = game + "|" + t.lowercase().replace(Regex("\\s+"), " ")

    private fun worth(t: String): Boolean =
        t.length >= 2 && t.any { it.isLetter() } &&
            t.none { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }

    // Needs "Usage access" permission; without it everything goes to one shared "global" cache.
    private fun updateGame() {
        try {
            val um = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 15000, now)
            val e = UsageEvents.Event()
            var pkg: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) pkg = e.packageName
            }
            if (pkg != null && pkg != packageName) game = pkg
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        scope.cancel()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) { }
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        if (::recognizer.isInitialized) recognizer.close()
        super.onDestroy()
    }
}
