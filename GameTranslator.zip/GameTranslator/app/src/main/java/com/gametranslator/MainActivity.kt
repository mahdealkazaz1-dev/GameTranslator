package com.gametranslator

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val langs = linkedMapOf(
        "English" to "en", "日本語 (Japanese)" to "ja",
        "한국어 (Korean)" to "ko", "中文 (Chinese)" to "zh"
    )

    private val projLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, TranslateService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "تم التشغيل، افتح اللعبة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("gt", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 8) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(TextView(this).apply { text = "مترجم الألعاب"; textSize = 26f })

        root.addView(label("لغة اللعبة"))
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs.keys.toList())
        val cur = prefs.getString("lang", "en")
        spin.setSelection(langs.values.indexOf(cur).coerceAtLeast(0))
        root.addView(spin)

        root.addView(label("مفتاح Claude API (اختياري، لترجمة أدق)"))
        val key = EditText(this).apply { setText(prefs.getString("key", "")); hint = "sk-ant-..." }
        root.addView(key)

        root.addView(btn("1) السماح بالعرض فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("2) معرفة اللعبة الحالية (اختياري)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(btn("▶ تشغيل الترجمة") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل خطوة 1 أولاً", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit()
                    .putString("lang", langs.values.toList()[spin.selectedItemPosition])
                    .putString("key", key.text.toString().trim())
                    .apply()
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projLauncher.launch(mpm.createScreenCaptureIntent())
            }
        })
        root.addView(btn("⏹ إيقاف") { stopService(Intent(this, TranslateService::class.java)) })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
