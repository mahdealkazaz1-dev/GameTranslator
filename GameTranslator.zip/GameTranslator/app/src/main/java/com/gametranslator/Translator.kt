package com.gametranslator

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * If an API key is set: Claude translates (better for game dialogue), in one batch.
 * Otherwise (or on failure): ML Kit on-device translation (free, offline after model download).
 */
class Translator(src: String, private val apiKey: String) {
    private val mlSrc = when (src) {
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        "zh" -> TranslateLanguage.CHINESE
        else -> TranslateLanguage.ENGLISH
    }
    private val ml by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(mlSrc)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
    }

    suspend fun translate(texts: List<String>): List<String?> {
        if (apiKey.isNotBlank()) {
            try {
                return withContext(Dispatchers.IO) { claude(texts) }
            } catch (_: Exception) { /* fall back to ML Kit */ }
        }
        return texts.map { t ->
            try {
                ml.downloadModelIfNeeded().await()
                ml.translate(t).await()
            } catch (_: Exception) { null }
        }
    }

    private fun claude(texts: List<String>): List<String> {
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 4000)
            .put(
                "system",
                "You translate mobile game UI text and dialogue into natural, simple Arabic. " +
                    "Keep character names, numbers and placeholders like {0} or %s unchanged. " +
                    "Reply with ONLY a JSON array of strings, same length and order as the input."
            )
            .put(
                "messages",
                JSONArray().put(
                    JSONObject().put("role", "user").put("content", JSONArray(texts).toString())
                )
            )
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 30000
        c.doOutput = true
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
        val resp = JSONObject(c.inputStream.bufferedReader().readText())
        val txt = resp.getJSONArray("content").getJSONObject(0).getString("text").trim()
            .removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val out = JSONArray(txt)
        require(out.length() == texts.size)
        return List(texts.size) { out.getString(it) }
    }
}
