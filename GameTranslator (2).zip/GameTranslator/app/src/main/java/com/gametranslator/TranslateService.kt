package com.gametranslator

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TranslateService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainH = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var thread: HandlerThread? = null
    private lateinit var wm: WindowManager
    private lateinit var recognizer: TextRecognizer
    private lateinit var translator: Translator
    private lateinit var dao: TrDao
    @Volatile private var frame: Bitmap? = null
    @Volatile private var frameSeq = 0L
    private var scale = 1f
    private var capW = 0
    private var capH = 0
    private var game = "global"

    // settings
    private var skipSingle = true
    private var skipLang = true
    private var shownErr: String? = null
    private var srcLang = "en"
    private var gloss: Map<String, String?> = emptyMap()
    private var glossLc: Map<String, String?> = emptyMap()
    private var ignore: Set<String> = emptySet()
    private var mode = "inplace"      // "inplace" = boxes over the text, "sub" = subtitle bar
    private var zone = "dialogue"
    private val langId by lazy { LanguageIdentification.getClient() }

    private var gen = 0
    @Volatile private var complete = true
    @Volatile private var renderAt = 0L
    private var lastItems: List<Item> = emptyList()
    private var job: Job? = null
    private val black = Paint().apply { color = Color.BLACK }

    // Screen areas to read (fractions of the screen) and the smallest text line to bother with.
    private class Zone(val regions: List<RectF>, val minLine: Float)

    private fun zoneOf(z: String) = when (z) {
        "dialogue" -> Zone(listOf(RectF(0.08f, 0.55f, 0.92f, 1f)), 0.025f)
        "dialogue_quest" -> Zone(listOf(RectF(0.08f, 0.55f, 0.92f, 1f), RectF(0f, 0.12f, 0.34f, 0.65f)), 0.022f)
        "menu" -> Zone(listOf(RectF(0.03f, 0.04f, 0.97f, 0.96f)), 0.02f)
        else -> Zone(listOf(RectF(0f, 0f, 1f, 1f)), 0.016f)
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        start(intent.getIntExtra("code", 0), data)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("gt", "Game Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, TranslateService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "gt")
            .setContentTitle("مترجم الألعاب شغال")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "إيقاف", stopPi
                ).build()
            )
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun start(code: Int, data: Intent) {
        val prefs = getSharedPreferences("gt", MODE_PRIVATE)
        val lang = prefs.getString("lang", "en") ?: "en"
        srcLang = lang
        mode = prefs.getString("mode", "inplace") ?: "inplace"
        zone = prefs.getString("zone", "dialogue") ?: "dialogue"
        skipSingle = prefs.getBoolean("skipSingle", true)
        skipLang = prefs.getBoolean("skipLang", true)
        ignore = (prefs.getString("ignore", "") ?: "")
            .split(",", "،", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
        gloss = Glossary.build(prefs.getString("glossary", "") ?: "")
        glossLc = gloss.mapKeys { it.key.lowercase() }

        val aiKey = prefs.getString("key", "") ?: ""
        val provider = prefs.getString("provider", null) ?: if (aiKey.isNotBlank()) "claude" else "mlkit"
        translator = Translator(
            lang,
            AiConfig(provider, aiKey, prefs.getString("model", "") ?: "", prefs.getString("baseUrl", "") ?: ""),
            gloss,
            prefs.getString("about", "") ?: ""
        )
        recognizer = when (lang) {
            "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        dao = AppDb.get(this).dao()
        wm = getSystemService(WindowManager::class.java)

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, mainH)

        thread = HandlerThread("gt-capture").also { it.start() }
        val (sw, sh) = screenSize()
        buildCapture(sw, sh)

        overlay = OverlayView(this, 1f / scale).also { it.subAtTop = prefs.getBoolean("subTop", true) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(overlay, lp)

        scope.launch { loop() }
    }

    private fun screenSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return b.width() to b.height()
    }

    // Builds (or rebuilds after rotation) the capture surface at the current screen size.
    // Capture is kept small (max 1100px) so heavy games don't stutter.
    private fun buildCapture(sw: Int, sh: Int) {
        scale = min(1f, 1100f / max(sw, sh))
        val cw = (sw * scale).toInt()
        val ch = (sh * scale).toInt()
        capW = cw
        capH = ch
        val old = reader
        val nr = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        nr.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try { frame = toBitmap(img, cw, ch); frameSeq++ } finally { img.close() }
            }
        }, Handler(thread!!.looper))
        reader = nr
        val dpi = resources.displayMetrics.densityDpi
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "gt", cw, ch, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nr.surface, null, null
            )
        } else {
            display!!.resize(cw, ch, dpi)
            display!!.surface = nr.surface
        }
        old?.close()
        frame = null
        overlay?.k = 1f / scale
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val bmp = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, w, h)
    }

    // ---------------- screen regions ----------------

    private fun rectsOf(f: Bitmap, zn: Zone): List<Rect> = zn.regions.map { r ->
        Rect(
            (r.left * f.width).toInt(), (r.top * f.height).toInt(),
            (r.right * f.width).toInt(), (r.bottom * f.height).toInt()
        )
    }

    // The subtitle bar (in capture px, relative to a region) so we never read our own text.
    private fun barIn(rect: Rect): Rect? {
        if (mode != "sub") return null
        val b = overlay?.bar ?: return null
        val l = (b.left * scale).toInt() - rect.left
        val t = (b.top * scale).toInt() - rect.top
        val r = (b.right * scale).toInt() - rect.left
        val bo = (b.bottom * scale).toInt() - rect.top
        return Rect(max(l, 0), max(t, 0), min(r, rect.width()), min(bo, rect.height()))
            .takeIf { it.width() > 0 && it.height() > 0 }
    }

    // Coarse brightness grid of a region (bar masked out). Used to notice that the screen changed.
    private fun sig(f: Bitmap, rect: Rect): IntArray {
        val w = rect.width()
        val h = rect.height()
        val px = IntArray(w * h)
        f.getPixels(px, 0, w, rect.left, rect.top, w, h)
        barIn(rect)?.let { m ->
            for (y in m.top until m.bottom) java.util.Arrays.fill(px, y * w + m.left, y * w + m.right, 0)
        }
        val gx = 48
        val gy = 27
        val out = IntArray(gx * gy)
        for (cy in 0 until gy) {
            val y0 = cy * h / gy
            val y1 = (cy + 1) * h / gy
            for (cx in 0 until gx) {
                val x0 = cx * w / gx
                val x1 = (cx + 1) * w / gx
                var sum = 0L
                var n = 0
                var y = y0
                while (y < y1) {
                    var x = x0
                    while (x < x1) {
                        val c = px[y * w + x]
                        sum += ((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)
                        n++
                        x += 3
                    }
                    y += 3
                }
                out[cy * gx + cx] = if (n > 0) (sum / n / 10).toInt() else 0
            }
        }
        return out
    }

    private fun changed(a: IntArray, b: IntArray): Boolean {
        if (a.size != b.size) return true
        var cells = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 14) cells++
        return cells > 6
    }

    private fun cropOf(f: Bitmap, rect: Rect): Bitmap {
        val out = Bitmap.createBitmap(rect.width(), rect.height(), Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(f, rect, Rect(0, 0, rect.width(), rect.height()), null)
        barIn(rect)?.let { c.drawRect(RectF(it), black) }
        return out
    }

    // ---------------- main loop ----------------

    private suspend fun loop() {
        val zn = zoneOf(zone)
        var lastSig: IntArray? = null
        var shown = ""
        var shownAt = 0L
        var lastOcr = 0L
        var dirtySince = 0L
        var settleUntil = 0L

        while (currentCoroutineContext().isActive) {
            delay(250)
            val (sw, sh) = screenSize()
            if ((sw * scale).toInt() != capW || (sh * scale).toInt() != capH) {
                buildCapture(sw, sh)   // screen rotated
                lastSig = null
                continue
            }
            val f = frame ?: continue
            val rects = rectsOf(f, zn)
            val s = rects.map { sig(f, it) }.reduce { a, b -> a + b }
            val prev = lastSig
            val moved = prev == null || changed(s, prev)
            lastSig = s
            val now = System.currentTimeMillis()
            // right after our own boxes appear the picture changes because of them: ignore that
            if (now < max(settleUntil, renderAt + 600)) continue
            if (moved && dirtySince == 0L) dirtySince = now

            // Boxes hide what changes underneath them, so while a translation is shown we
            // re-read the text now and then (often right after a change, rarely when idle).
            val verifyEvery = if (now - shownAt < 8000) 1200L else 3000L
            val verify = mode == "inplace" && shown.isNotEmpty() && now - lastOcr > verifyEvery
            val retry = shown.isNotEmpty() && !complete && job?.isActive != true && now - lastOcr > 2000
            // new text: read it once the picture stops changing (typing effect), or after 1s anyway
            val ready = dirtySince != 0L && (!moved || now - dirtySince > 1000)
            if (retry) { lastOcr = now; apply(lastItems); continue }
            if (!(ready || verify)) continue
            if (now - lastOcr < 400) continue

            // "over the text" mode: hide our boxes for one frame so OCR sees the real game text.
            var shot = f
            if (mode == "inplace" && shown.isNotEmpty()) {
                val seq = frameSeq
                withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE }
                val t0 = System.currentTimeMillis()
                while (frameSeq == seq && System.currentTimeMillis() - t0 < 450) delay(20)
                shot = frame ?: f
                withContext(Dispatchers.Main) { overlay?.visibility = View.VISIBLE }
            }

            lastOcr = System.currentTimeMillis()
            dirtySince = 0L
            val items = try { ocr(shot, zn) } catch (_: Exception) { continue }
            val key = items.joinToString("¦") { it.src }
            if (key == shown) continue
            shown = key
            shownAt = System.currentTimeMillis()
            lastItems = items
            apply(items)
            if (mode == "inplace") settleUntil = System.currentTimeMillis() + 700
        }
    }

    private suspend fun ocr(f: Bitmap, zn: Zone): List<Item> {
        updateGame()
        val items = ArrayList<Item>()
        val rects = rectsOf(f, zn)
        for ((ri, rect) in rects.withIndex()) {
            val res = recognizer.process(InputImage.fromBitmap(cropOf(f, rect), 0)).await()
            for (b in res.textBlocks) {
                val bb = b.boundingBox ?: continue
                val lineH = b.lines.firstOrNull()?.boundingBox?.height() ?: bb.height()
                if (lineH < zn.minLine * capH) continue
                val t = b.text.replace('\n', ' ').trim()
                if (!worth(t) || !rightLanguage(t)) continue
                items.add(
                    Item(
                        t,
                        Rect(bb.left + rect.left, bb.top + rect.top, bb.right + rect.left, bb.bottom + rect.top),
                        null, ri
                    )
                )
            }
        }
        return items
    }

    // Subtitle mode reads each region as one passage, so sentences keep their context.
    private fun merge(items: List<Item>): List<Item> =
        items.groupBy { it.region }.toSortedMap().values.map { g ->
            val sorted = g.sortedWith(compareBy({ it.box.top / 12 }, { it.box.left }))
            val u = Rect(sorted[0].box)
            sorted.forEach { u.union(it.box) }
            Item(sorted.joinToString("\n") { it.src }, u, null, sorted[0].region)
        }

    private fun apply(items: List<Item>) {
        val my = ++gen
        complete = false
        job?.cancel()
        job = scope.launch {
            val units = if (mode == "sub") merge(items) else items
            units.forEach { quick(it.src)?.let { q -> it.ar = q } }

            // 1) cache: known texts appear instantly
            val todo = units.filter { it.ar == null }
            val cached = dao.get(todo.map { id(it.src) }).associateBy { it.id }
            todo.forEach { cached[id(it.src)]?.let { e -> it.ar = e.ar } }
            render(units, my)
            if (my == gen && units.all { it.ar != null }) complete = true

            // 2) translate only what's new (with a timeout so nothing hangs), then remember it
            val missing = units.filter { it.ar == null }.distinctBy { id(it.src) }
            if (missing.isNotEmpty()) {
                val out = withTimeoutOrNull(12000) { translator.translate(missing.map { it.src }) } ?: return@launch
                translator.lastError?.let { e ->
                    translator.lastError = null
                    if (e != shownErr) {
                        shownErr = e
                        mainH.post {
                            Toast.makeText(applicationContext, "فشل الذكاء الاصطناعي: $e (استخدمت الترجمة المجانية)", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                val rows = missing.mapIndexedNotNull { i, m ->
                    out.getOrNull(i)?.let { TrEntry(id(m.src), game, m.src, it) }
                }
                if (rows.isNotEmpty()) dao.put(rows)
                val map = rows.associateBy { it.id }
                units.forEach { if (it.ar == null) it.ar = map[id(it.src)]?.ar }
                render(units, my)
                if (my == gen) complete = units.all { it.ar != null }
            }
        }
    }

    private suspend fun render(units: List<Item>, my: Int) = withContext(Dispatchers.Main) {
        if (my != gen) return@withContext
        if (mode == "sub") overlay?.setSubtitle(units.mapNotNull { it.ar }.joinToString("\n"))
        else overlay?.setItems(units.toList())
        renderAt = System.currentTimeMillis()
    }

    // Skips chat/text written in another language than the game's.
    private suspend fun rightLanguage(t: String): Boolean {
        if (!skipLang || t.length < 15) return true
        return try {
            val code = langId.identifyLanguage(t).await()
            code == "und" || code == srcLang
        } catch (_: Exception) { true }
    }

    private fun id(t: String) = game + "|" + t.lowercase().replace(Regex("\\s+"), " ")

    private fun clean(x: String) = x.trim().trim(':', '.', ',', '!', '?', '-', '[', ']').lowercase()

    // Instant answer from glossary (fixed terms) or the UI-word dictionary; null if none.
    private fun quick(t: String): String? {
        val k = clean(t)
        return glossLc[k] ?: Glossary.ui[k]
    }

    // Decides if a text block is worth translating. Filters names, ping, IDs, kept terms.
    private fun worth(t: String): Boolean {
        if (t.length < 2 || t.none { it.isLetter() }) return false
        if (t.any { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }) return false
        if (t.count { it.isLetter() } < t.length / 2) return false
        val tokens = t.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.all { clean(it) in ignore }) return false
        val k = clean(t)
        if (glossLc.containsKey(k) && glossLc[k] == null) return false   // game name kept as-is
        if (quick(t) != null) return true                                 // dictionary word / fixed term
        if (skipSingle && tokens.size == 1) return false
        if (tokens.all { nameLike(it) }) return false
        return true
    }

    // mahdialkazaz-style names: digits mixed with letters, inner capitals (StReXpt), @handles
    private fun nameLike(w: String): Boolean =
        (w.any { it.isDigit() } && w.any { it.isLetter() }) ||
            Regex("[a-z][A-Z]").containsMatchIn(w) || w.startsWith("@")

    // Needs "Usage access" permission; without it everything goes to one shared "global" cache.
    private fun updateGame() {
        try {
            val um = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 15000, now)
            val e = UsageEvents.Event()
            var pkg: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) pkg = e.packageName
            }
            if (pkg != null && pkg != packageName) game = pkg
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        scope.cancel()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) { }
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        if (::recognizer.isInitialized) recognizer.close()
        super.onDestroy()
    }
}
