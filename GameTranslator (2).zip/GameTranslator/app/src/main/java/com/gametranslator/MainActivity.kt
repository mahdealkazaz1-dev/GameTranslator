package com.gametranslator

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val langs = linkedMapOf(
        "English" to "en", "日本語 (Japanese)" to "ja",
        "한국어 (Korean)" to "ko", "中文 (Chinese)" to "zh"
    )

    private val projLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, TranslateService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "تم التشغيل، افتح اللعبة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("gt", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 8) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(TextView(this).apply { text = "مترجم الألعاب"; textSize = 26f })

        root.addView(label("لغة اللعبة"))
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs.keys.toList())
        val cur = prefs.getString("lang", "en")
        spin.setSelection(langs.values.indexOf(cur).coerceAtLeast(0))
        root.addView(spin)

        root.addView(label("طريقة العرض"))
        val modeSp = Spinner(this)
        modeSp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("شريط ترجمة (بدون تغطية، الأفضل للحوار)", "فوق النص مباشرة (للقوائم)")
        )
        modeSp.setSelection(if (prefs.getString("mode", "inplace") == "inplace") 1 else 0)
        root.addView(modeSp)

        root.addView(label("منطقة الترجمة"))
        val zones = listOf(
            "dialogue" to "الحوار (أسفل الشاشة)",
            "dialogue_quest" to "الحوار + المهمات (يسار)",
            "menu" to "القوائم (وسط الشاشة)",
            "all" to "كل الشاشة"
        )
        val zoneSp = Spinner(this)
        zoneSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, zones.map { it.second })
        zoneSp.setSelection(zones.indexOfFirst { it.first == prefs.getString("zone", "dialogue") }.coerceAtLeast(0))
        root.addView(zoneSp)

        val topCb = CheckBox(this).apply {
            text = "شريط الترجمة بأعلى الشاشة"
            isChecked = prefs.getBoolean("subTop", true)
        }
        root.addView(topCb)

        root.addView(label("مزوّد الترجمة بالذكاء الاصطناعي"))
        val provSpin = Spinner(this)
        provSpin.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Providers.list.map { it.label }
        )
        val savedKey = prefs.getString("key", "") ?: ""
        val savedProv = prefs.getString("provider", null) ?: if (savedKey.isNotBlank()) "claude" else "mlkit"
        provSpin.setSelection(Providers.list.indexOfFirst { it.id == savedProv }.coerceAtLeast(0))
        root.addView(provSpin)
        root.addView(label("مفتاح API"))
        val key = EditText(this).apply { setText(savedKey); hint = "API key" }
        root.addView(key)
        root.addView(label("اسم النموذج (فارغ = الافتراضي)"))
        val model = EditText(this).apply { setText(prefs.getString("model", "")) }
        root.addView(model)
        root.addView(label("رابط API (فارغ = الافتراضي، ومطلوب للمخصص)"))
        val baseUrl = EditText(this).apply { setText(prefs.getString("baseUrl", "")) }
        root.addView(baseUrl)
        provSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, rowId: Long) {
                val d = Providers.list[pos]
                model.hint = d.model.ifEmpty { "اسم النموذج" }
                baseUrl.hint = d.base.ifEmpty { "https://.../v1" }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val skip = CheckBox(this).apply {
            text = "تجاهل الكلمات المفردة (غالباً أسماء لاعبين وأماكن)"
            isChecked = prefs.getBoolean("skipSingle", true)
        }
        root.addView(skip)
        root.addView(label("أسماء أو كلمات تتجاهلها (افصل بفاصلة)"))
        val ign = EditText(this).apply { setText(prefs.getString("ignore", "")); hint = "Echo, Holly, Odinn" }
        root.addView(ign)

        root.addView(label("وصف اللعبة للمترجم (اختياري، يحسّن ترجمة Claude)"))
        val about = EditText(this).apply {
            setText(prefs.getString("about", ""))
            hint = "LifeAfter: zombie survival, factions, base building"
        }
        root.addView(about)
        val lng = CheckBox(this).apply {
            text = "تجاهل الشات واللغات الثانية (غير لغة اللعبة)"
            isChecked = prefs.getBoolean("skipLang", true)
        }
        root.addView(lng)
        root.addView(label("مصطلحات إضافية: سطر لكل مصطلح. المصطلح لحاله يبقى بالإنكليزي، أو مصطلح=ترجمة"))
        val glo = EditText(this).apply {
            setText(prefs.getString("glossary", ""))
            hint = "Rathalos\nGreat Sword=السيف العظيم"
            minLines = 3
        }
        root.addView(glo)

        root.addView(btn("1) السماح بالعرض فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("2) معرفة اللعبة الحالية (اختياري)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(btn("▶ تشغيل الترجمة") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل خطوة 1 أولاً", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit()
                    .putString("lang", langs.values.toList()[spin.selectedItemPosition])
                    .putString("key", key.text.toString().trim())
                    .putString("provider", Providers.list[provSpin.selectedItemPosition].id)
                    .putString("mode", if (modeSp.selectedItemPosition == 1) "inplace" else "sub")
                    .putString("zone", zones[zoneSp.selectedItemPosition].first)
                    .putBoolean("subTop", topCb.isChecked)
                    .putString("model", model.text.toString().trim())
                    .putString("baseUrl", baseUrl.text.toString().trim())
                    .putBoolean("skipSingle", skip.isChecked)
                    .putString("ignore", ign.text.toString())
                    .putBoolean("skipLang", lng.isChecked)
                    .putString("glossary", glo.text.toString())
                    .putString("about", about.text.toString())
                    .apply()
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projLauncher.launch(mpm.createScreenCaptureIntent())
            }
        })
        root.addView(btn("⏹ إيقاف") { stopService(Intent(this, TranslateService::class.java)) })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
