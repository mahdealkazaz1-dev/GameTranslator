package com.gametranslator

/**
 * Built-in game knowledge:
 *  keep  -> proper names that must stay as written (monsters, places, companions)
 *  fixed -> terms with a chosen Arabic translation
 *  ui    -> common single UI words (translated instantly from this table, no API call)
 */
object Glossary {
    val keep = listOf(
        // Monster Hunter Outlanders
        "Palico", "Rutaco", "Trillan", "Radiantite", "Radiant Species", "Radiant",
        "Aesoland", "Kulune Village", "Giantwood", "Grand Archipelago", "Rotfall Abyss",
        "Ruger Aidal", "Kelbi", "Raphinos", "Elegant Coralbird", "Flashfly", "Vigorwasp",
        // Monster Hunter series monsters
        "Rathalos", "Rathian", "Diablos", "Nergigante", "Teostra", "Kushala Daora",
        "Zinogre", "Tobi-Kadachi", "Anjanath", "Great Jagras", "Kulu-Ya-Ku", "Pukei-Pukei",
        "Barroth", "Jyuratodus", "Odogaron", "Legiana", "Paolumu", "Tzitzi-Ya-Ku",
        "Nargacuga", "Tigrex", "Khezu", "Gore Magala", "Velkhana", "Mizutsune", "Magnamalo",
        // LifeAfter
        "LifeAfter", "Dawn Break", "Dawn", "Ark City", "Ark Science", "Starfire"
    )

    val fixed = mapOf(
        "Great Sword" to "السيف العظيم", "Long Sword" to "السيف الطويل",
        "Sword and Shield" to "السيف والدرع", "Dual Blades" to "السيفان المزدوجان",
        "Hammer" to "المطرقة", "Hunting Horn" to "بوق الصيد", "Lance" to "الرمح",
        "Gunlance" to "الرمح المدفعي", "Switch Axe" to "الفأس المتحول",
        "Charge Blade" to "سيف الشحن", "Insect Glaive" to "رمح الحشرات",
        "Bow" to "القوس", "Light Bowgun" to "النشاب الخفيف", "Heavy Bowgun" to "النشاب الثقيل",
        "Buddy" to "الرفيق", "Buddies" to "الرفاق",
        "Assault" to "هجوم", "Disruptor" to "معطِّل", "Support" to "دعم",
        // LifeAfter factions
        "Trade Alliance" to "تحالف التجارة", "Empire" to "الإمبراطورية", "Church" to "الكنيسة"
    )

    val ui = mapOf(
        "shop" to "المتجر", "store" to "المتجر", "channel" to "القناة", "settings" to "الإعدادات",
        "quest" to "مهمة", "quests" to "المهمات", "mission" to "مهمة", "missions" to "المهمات",
        "inventory" to "الحقيبة", "backpack" to "الحقيبة", "storage" to "المخزن",
        "equipment" to "العتاد", "weapons" to "الأسلحة", "weapon" to "السلاح",
        "armor" to "الدرع", "items" to "العناصر", "item" to "عنصر", "craft" to "صناعة",
        "crafting" to "الصناعة", "map" to "الخريطة", "friends" to "الأصدقاء", "guild" to "النقابة",
        "party" to "الفريق", "chat" to "الدردشة", "mail" to "البريد", "events" to "الفعاليات",
        "event" to "فعالية", "rewards" to "المكافآت", "reward" to "المكافأة", "claim" to "استلام",
        "confirm" to "تأكيد", "cancel" to "إلغاء", "back" to "رجوع", "next" to "التالي",
        "skip" to "تخطي", "start" to "ابدأ", "continue" to "متابعة", "close" to "إغلاق",
        "accept" to "قبول", "decline" to "رفض", "upgrade" to "ترقية", "level" to "المستوى",
        "skills" to "المهارات", "skill" to "المهارة", "battle" to "معركة", "hunt" to "صيد",
        "home" to "الرئيسية", "gacha" to "السحب", "announcements" to "الإعلانات",
        "tasks" to "المهام", "achievements" to "الإنجازات", "ranking" to "الترتيب",
        "auto" to "تلقائي", "loading" to "جارٍ التحميل", "download" to "تنزيل", "update" to "تحديث",
        "login" to "تسجيل الدخول", "logout" to "تسجيل الخروج", "save" to "حفظ", "load" to "تحميل",
        "yes" to "نعم", "no" to "لا", "ok" to "موافق", "retry" to "إعادة المحاولة", "exit" to "خروج",
        "menu" to "القائمة", "profile" to "الملف الشخصي", "repair" to "إصلاح", "sell" to "بيع",
        "buy" to "شراء", "use" to "استخدام", "equip" to "تجهيز", "unequip" to "إزالة",
        "details" to "التفاصيل", "info" to "معلومات", "tutorial" to "الشرح", "daily" to "يومي",
        "weekly" to "أسبوعي", "free" to "مجاني", "new" to "جديد", "online" to "متصل",
        "offline" to "غير متصل", "invite" to "دعوة", "join" to "انضمام", "leave" to "مغادرة",
        "ready" to "جاهز", "recruitment" to "التجنيد", "trade" to "تبادل", "pause" to "إيقاف مؤقت",
        "resume" to "استئناف", "collect" to "جمع", "complete" to "مكتمل", "reset" to "إعادة ضبط",
        // survival games
        "hunger" to "الجوع", "thirst" to "العطش", "stamina" to "التحمل", "health" to "الصحة",
        "durability" to "المتانة", "supplies" to "الإمدادات", "airdrop" to "إنزال جوي",
        "camp" to "المخيم", "base" to "القاعدة", "build" to "بناء", "infected" to "المصابون",
        "zombies" to "الزومبي", "survivor" to "ناجٍ", "survivors" to "الناجون", "vehicle" to "المركبة",
        "fuel" to "الوقود", "wood" to "خشب", "stone" to "حجر", "iron" to "حديد", "water" to "ماء",
        "food" to "طعام", "medicine" to "دواء", "ammo" to "الذخيرة", "resources" to "الموارد",
        "territory" to "الإقليم", "faction" to "الفصيل", "raid" to "غارة", "sanctuary" to "الملاذ",
        "gather" to "جمع الموارد", "explore" to "استكشاف", "attack" to "هجوم", "defense" to "دفاع"
    )

    /** Built-in terms + the user's own lines ("Term" keeps it, "Term=ترجمة" fixes it). */
    fun build(user: String): Map<String, String?> {
        val m = LinkedHashMap<String, String?>()
        keep.forEach { m[it] = null }
        m.putAll(fixed)
        user.split("\n", ";").map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            val i = line.indexOf('=')
            val k = (if (i > 0) line.substring(0, i) else line).trim()
            val v = if (i > 0) line.substring(i + 1).trim().ifEmpty { null } else null
            if (k.isNotEmpty()) {
                m.keys.removeAll { it.equals(k, ignoreCase = true) }
                m[k] = v
            }
        }
        return m
    }
}
