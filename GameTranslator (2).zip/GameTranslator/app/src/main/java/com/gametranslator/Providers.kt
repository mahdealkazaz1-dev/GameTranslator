package com.gametranslator

data class Provider(val id: String, val label: String, val model: String, val base: String)

data class AiConfig(val provider: String, val key: String, val model: String, val baseUrl: String)

object Providers {
    // Default model names change often: the model field in the app overrides these.
    val list = listOf(
        Provider("mlkit", "بدون مفتاح (ML Kit مجاني)", "", ""),
        Provider("claude", "Claude (Anthropic)", "claude-haiku-5-5", "https://api.anthropic.com/v1/messages"),
        Provider("gemini", "Gemini (Google)", "gemini-2.5-flash", "https://generativelanguage.googleapis.com/v1beta"),
        Provider("deepseek", "DeepSeek (صيني)", "deepseek-flash", "https://api.deepseek.com"),
        Provider("qwen", "Qwen (علي بابا، صيني)", "qwen-plus", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"),
        Provider("glm", "GLM (Zhipu، صيني)", "glm-4-flash", "https://open.bigmodel.cn/api/paas/v4"),
        Provider("kimi", "Kimi (Moonshot، صيني)", "kimi-k2-0905-preview", "https://api.moonshot.ai/v1"),
        Provider("openai", "OpenAI", "gpt-4o-mini", "https://api.openai.com/v1"),
        Provider("custom", "مخصص (متوافق مع OpenAI)", "", "")
    )

    fun byId(id: String): Provider = list.firstOrNull { it.id == id } ?: list[0]
}
