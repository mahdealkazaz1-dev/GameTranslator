package com.gametranslator

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

data class Item(val src: String, val box: Rect, var ar: String? = null, val region: Int = 0)

/**
 * Full-screen, non-touchable layer. Two display modes:
 *  - subtitle bar: one clean panel with the translation (does not cover the game text)
 *  - in-place boxes: Arabic boxes painted over each original text block
 */
class OverlayView(ctx: Context, var k: Float) : View(ctx) {
    private var items: List<Item> = emptyList()
    private var sub: String = ""
    private var barLayout: StaticLayout? = null
    var subAtTop = true

    /** Where the subtitle bar sits on screen (screen px); read by the service to mask it from OCR. */
    @Volatile var bar: RectF? = null

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE14141C.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setItems(l: List<Item>) { items = l; invalidate() }

    fun setSubtitle(t: String) { sub = t; layoutBar(); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutBar()
    }

    private fun layoutBar() {
        if (sub.isBlank() || width == 0 || height == 0) { barLayout = null; bar = null; return }
        val maxW = (width * 0.8f).toInt()
        var size = height * 0.045f
        var l: StaticLayout
        while (true) {
            tp.textSize = size
            l = StaticLayout.Builder.obtain(sub, 0, sub.length, tp, maxW - 48)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .build()
            if (l.height <= height * 0.4f || size <= 20f) break
            size -= 2f
        }
        barLayout = l
        val bw = maxW.toFloat()
        val bh = l.height + 40f
        val left = (width - bw) / 2f
        val top = if (subAtTop) height * 0.03f else height - bh - height * 0.03f
        bar = RectF(left, top, left + bw, top + bh)
    }

    override fun onDraw(c: Canvas) {
        val b = bar
        val bl = barLayout
        if (b != null && bl != null) {
            c.drawRoundRect(b, 22f, 22f, bg)
            c.save()
            c.translate(b.left + 24f, b.top + 20f)
            bl.draw(c)
            c.restore()
        }
        for (it in items) {
            val ar = it.ar ?: continue
            val r = RectF(it.box.left * k, it.box.top * k, it.box.right * k, it.box.bottom * k)
            r.inset(-8f, -5f)
            c.drawRoundRect(r, 14f, 14f, bg)
            val w = max(r.width() - 16f, 60f).toInt()
            var size = min(r.height(), 60f)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(ar, 0, ar.length, tp, w)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                if (layout.height <= r.height() - 6f || size <= 18f) break
                size -= 2f
            }
            c.save()
            c.translate(r.left + 8f, r.top + (r.height() - layout.height) / 2f)
            layout.draw(c)
            c.restore()
        }
    }
}
