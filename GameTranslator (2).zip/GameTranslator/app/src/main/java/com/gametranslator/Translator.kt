package com.gametranslator

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Translates with the chosen AI provider (Claude, Gemini, or any OpenAI-compatible API such as
 * DeepSeek / Qwen / GLM / Kimi / OpenAI / custom). If it fails or no key is set, falls back to
 * ML Kit on-device translation (glossary terms are cut out, the rest translated, then rejoined).
 * gloss: term -> fixed Arabic translation, or null = keep the term as written.
 */
class Translator(
    src: String,
    private val ai: AiConfig,
    private val gloss: Map<String, String?>,
    private val about: String = ""
) {
    @Volatile var lastError: String? = null

    private val mlSrc = when (src) {
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        "zh" -> TranslateLanguage.CHINESE
        else -> TranslateLanguage.ENGLISH
    }
    private val ml by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(mlSrc)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
    }
    private val glossLc: Map<String, String?> = gloss.mapKeys { it.key.lowercase() }
    private val rx: Regex? =
        if (gloss.isEmpty()) null
        else Regex(
            "(?<![\\p{L}\\p{N}])(" +
                gloss.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) } +
                ")(?![\\p{L}\\p{N}])",
            RegexOption.IGNORE_CASE
        )

    suspend fun translate(texts: List<String>): List<String?> {
        if (ai.provider != "mlkit" && ai.key.isNotBlank()) {
            try {
                return withContext(Dispatchers.IO) { remote(texts) }
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
            }
        }
        return texts.map { mlWithGlossary(it) }
    }

    // ---------------- ML Kit (free, offline) ----------------

    private suspend fun mlRaw(t: String): String? = try {
        ml.downloadModelIfNeeded().await()
        ml.translate(t).await()
    } catch (_: Exception) { null }

    private suspend fun mlWithGlossary(t: String): String? {
        val r = rx ?: return mlRaw(t)
        val parts = ArrayList<String>()
        var last = 0
        for (m in r.findAll(t)) {
            val before = t.substring(last, m.range.first)
            if (before.any { it.isLetter() }) parts.add(mlRaw(before) ?: return null)
            else if (before.isNotBlank()) parts.add(before.trim())
            parts.add(glossLc[m.value.lowercase()] ?: m.value)
            last = m.range.last + 1
        }
        val tail = t.substring(last)
        if (tail.any { it.isLetter() }) parts.add(mlRaw(tail) ?: return null)
        else if (tail.isNotBlank()) parts.add(tail.trim())
        return parts.joinToString(" ")
    }

    // ---------------- AI providers ----------------

    private fun systemPrompt(): String {
        val keep = gloss.filter { it.value == null }.keys
        val fixed = gloss.filter { it.value != null }
        val g = StringBuilder()
        if (keep.isNotEmpty())
            g.append(" Keep these names exactly as written in English: ").append(keep.joinToString(", ")).append(".")
        if (fixed.isNotEmpty())
            g.append(" Always translate these terms as: ")
                .append(fixed.entries.joinToString("; ") { "${it.key} = ${it.value}" }).append(".")
        return "You translate mobile game UI text and dialogue into natural, simple Arabic" +
            (if (about.isNotBlank()) " for this game: $about. " else ". ") +
            "Use common gamer terminology, keep UI labels short enough to fit a button, " +
            "and keep dialogue natural rather than literal. " +
            "Keep character names, numbers and placeholders like {0} or %s unchanged." + g +
            " Reply with ONLY a JSON array of strings, same length and order as the input."
    }

    private fun remote(texts: List<String>): List<String> {
        val p = Providers.byId(ai.provider)
        val model = ai.model.ifBlank { p.model }
        val base = ai.baseUrl.ifBlank { p.base }
        if (base.isBlank()) error("أدخل رابط API")
        if (model.isBlank()) error("أدخل اسم النموذج")
        val sys = systemPrompt()
        val user = JSONArray(texts).toString()
        val raw = when (ai.provider) {
            "claude" -> callClaude(base, model, sys, user)
            "gemini" -> callGemini(base, model, sys, user)
            else -> callOpenAi(base, model, sys, user)
        }
        val out = parseArray(raw)
        require(out.length() == texts.size) { "عدد الترجمات غير مطابق" }
        return List(texts.size) { out.getString(it) }
    }

    private fun callClaude(url: String, model: String, sys: String, user: String): String {
        val body = JSONObject().put("model", model).put("max_tokens", 4000).put("system", sys)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val r = post(url, mapOf("x-api-key" to ai.key, "anthropic-version" to "2023-06-01"), body)
        return JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun callGemini(base: String, model: String, sys: String, user: String): String {
        val url = base.trimEnd('/') + "/models/" + model + ":generateContent"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))
                )
            )
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
        val r = post(url, mapOf("x-goog-api-key" to ai.key), body)
        val parts = JSONObject(r).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    // DeepSeek, Qwen, GLM, Kimi, OpenAI, and any custom OpenAI-compatible endpoint
    private fun callOpenAi(base: String, model: String, sys: String, user: String): String {
        val url = base.trimEnd('/') + "/chat/completions"
        val body = JSONObject().put("model", model).put("temperature", 0.2)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", sys))
                    .put(JSONObject().put("role", "user").put("content", user))
            )
        val r = post(url, mapOf("Authorization" to "Bearer ${ai.key}"), body)
        return JSONObject(r).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 40000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)
            ?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) error("HTTP $code ${text.take(160)}")
        return text
    }

    private fun parseArray(raw: String): JSONArray {
        val t = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = t.indexOf('[')
        val b = t.lastIndexOf(']')
        require(a >= 0 && b > a) { "رد غير متوقع من النموذج" }
        return JSONArray(t.substring(a, b + 1))
    }
}
