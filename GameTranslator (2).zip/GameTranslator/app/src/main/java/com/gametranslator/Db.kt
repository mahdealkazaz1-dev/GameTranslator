package com.gametranslator

import android.content.Context
import androidx.room.*

/** id = game package + "|" + normalized source text */
@Entity(tableName = "tr")
data class TrEntry(@PrimaryKey val id: String, val game: String, val src: String, val ar: String)

@Dao
interface TrDao {
    @Query("SELECT * FROM tr WHERE id IN (:ids)")
    suspend fun get(ids: List<String>): List<TrEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(e: List<TrEntry>)

    @Query("SELECT * FROM tr WHERE game = :g")
    suspend fun all(g: String): List<TrEntry>
}

@Database(entities = [TrEntry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TrDao

    companion object {
        fun get(c: Context): AppDb =
            Room.databaseBuilder(c.applicationContext, AppDb::class.java, "gt.db").build()
    }
}
