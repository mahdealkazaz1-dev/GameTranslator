package com.gametranslator

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TranslateService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainH = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var thread: HandlerThread? = null
    private lateinit var wm: WindowManager
    private lateinit var recognizer: TextRecognizer
    private lateinit var translator: Translator
    private lateinit var dao: TrDao
    @Volatile private var frame: Bitmap? = null
    @Volatile private var frameSeq = 0L
    private var scale = 1f
    private var game = "global"
    private var skipSingle = true
    private var skipLang = true
    private var shownErr: String? = null
    private var srcLang = "en"
    private var gloss: Map<String, String?> = emptyMap()
    private var glossLc: Map<String, String?> = emptyMap()
    private val langId by lazy { LanguageIdentification.getClient() }
    private var ignore: Set<String> = emptySet()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        start(intent.getIntExtra("code", 0), data)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("gt", "Game Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, TranslateService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "gt")
            .setContentTitle("مترجم الألعاب شغال")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "إيقاف", stopPi
                ).build()
            )
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun start(code: Int, data: Intent) {
        val prefs = getSharedPreferences("gt", MODE_PRIVATE)
        val lang = prefs.getString("lang", "en") ?: "en"
        skipSingle = prefs.getBoolean("skipSingle", true)
        skipLang = prefs.getBoolean("skipLang", true)
        srcLang = lang
        gloss = Glossary.build(prefs.getString("glossary", "") ?: "")
        glossLc = gloss.mapKeys { it.key.lowercase() }
        ignore = (prefs.getString("ignore", "") ?: "")
            .split(",", "،", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
        val aiKey = prefs.getString("key", "") ?: ""
        val provider = prefs.getString("provider", null) ?: if (aiKey.isNotBlank()) "claude" else "mlkit"
        translator = Translator(
            lang,
            AiConfig(provider, aiKey, prefs.getString("model", "") ?: "", prefs.getString("baseUrl", "") ?: ""),
            gloss,
            prefs.getString("about", "") ?: ""
        )
        recognizer = when (lang) {
            "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        dao = AppDb.get(this).dao()
        wm = getSystemService(WindowManager::class.java)

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, mainH)

        thread = HandlerThread("gt-capture").also { it.start() }
        val (sw, sh) = screenSize()
        buildCapture(sw, sh)

        overlay = OverlayView(this, 1f / scale)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(overlay, lp)

        scope.launch { loop() }
    }

    private var capW = 0
    private var capH = 0

    private fun screenSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return b.width() to b.height()
    }

    // Builds (or rebuilds after rotation) the capture surface at the current screen size.
    private fun buildCapture(sw: Int, sh: Int) {
        scale = min(1f, 1400f / max(sw, sh))
        val cw = (sw * scale).toInt()
        val ch = (sh * scale).toInt()
        capW = cw
        capH = ch
        val old = reader
        val nr = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        nr.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try { frame = toBitmap(img, cw, ch); frameSeq++ } finally { img.close() }
            }
        }, Handler(thread!!.looper))
        reader = nr
        val dpi = resources.displayMetrics.densityDpi
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "gt", cw, ch, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nr.surface, null, null
            )
        } else {
            display!!.resize(cw, ch, dpi)
            display!!.surface = nr.surface
        }
        old?.close()
        frame = null
        overlay?.k = 1f / scale
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val bmp = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, w, h)
    }

    // Coarse luminance grid: tells us if the screen really changed.
    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(24 * 40)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(a.size) { (Color.red(a[it]) * 3 + Color.green(a[it]) * 6 + Color.blue(a[it])) / 10 }
    }

    private fun changed(a: IntArray, b: IntArray): Boolean {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return d / a.size > 4
    }

    private suspend fun loop() {
        var last: IntArray? = null
        var lastWork = 0L
        while (currentCoroutineContext().isActive) {
            delay(600)
            val (sw, sh) = screenSize()
            if ((sw * scale).toInt() != capW || (sh * scale).toInt() != capH) {
                // screen rotated (portrait <-> landscape): rebuild capture
                buildCapture(sw, sh)
                last = null
                continue
            }
            val f = frame ?: continue
            val s = sig(f)
            val prev = last
            if (prev != null && !changed(s, prev)) continue
            if (System.currentTimeMillis() - lastWork < 1200) continue
            lastWork = System.currentTimeMillis()

            // Hide our own boxes for a moment so OCR sees the real game text.
            val seq = frameSeq
            withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE }
            val t0 = System.currentTimeMillis()
            while (frameSeq == seq && System.currentTimeMillis() - t0 < 500) delay(30)
            val shot = frame?.copy(Bitmap.Config.ARGB_8888, false)
            withContext(Dispatchers.Main) {
                overlay?.setItems(emptyList())
                overlay?.visibility = View.VISIBLE
            }
            if (shot != null) {
                try { process(shot) } catch (_: Exception) { }
            }
            delay(250)
            last = frame?.let { sig(it) }
        }
    }

    private suspend fun process(shot: Bitmap) {
        updateGame()
        val res = recognizer.process(InputImage.fromBitmap(shot, 0)).await()
        val items = ArrayList<Item>()
        for (b in res.textBlocks) {
            val box = b.boundingBox ?: continue
            val t = b.text.replace('\n', ' ').trim()
            if (!worth(t)) continue
            if (!rightLanguage(t)) continue
            items.add(Item(t, box))
        }
        if (items.isEmpty()) return

        // 0) built-in dictionary: UI words and fixed game terms, instant
        items.forEach { quick(it.src)?.let { q -> it.ar = q } }

        // 1) cache: known texts appear instantly
        val todo = items.filter { it.ar == null }
        val cached = dao.get(todo.map { id(it.src) }).associateBy { it.id }
        todo.forEach { cached[id(it.src)]?.let { e -> it.ar = e.ar } }
        show(items)

        // 2) translate only what's new, then store it for next time
        val missing = items.filter { it.ar == null }.distinctBy { id(it.src) }
        if (missing.isNotEmpty()) {
            val out = translator.translate(missing.map { it.src })
            translator.lastError?.let { e ->
                translator.lastError = null
                if (e != shownErr) {
                    shownErr = e
                    mainH.post {
                        Toast.makeText(applicationContext, "فشل الذكاء الاصطناعي: $e (استخدمت الترجمة المجانية)", Toast.LENGTH_LONG).show()
                    }
                }
            }
            val rows = missing.mapIndexedNotNull { i, m ->
                out.getOrNull(i)?.let { TrEntry(id(m.src), game, m.src, it) }
            }
            if (rows.isNotEmpty()) dao.put(rows)
            val map = rows.associateBy { it.id }
            items.forEach { if (it.ar == null) it.ar = map[id(it.src)]?.ar }
            show(items)
        }
    }

    // Skips chat/text written in another language than the game's.
    private suspend fun rightLanguage(t: String): Boolean {
        if (!skipLang || t.length < 15) return true
        return try {
            val code = langId.identifyLanguage(t).await()
            code == "und" || code == srcLang
        } catch (_: Exception) { true }
    }

    private suspend fun show(items: List<Item>) =
        withContext(Dispatchers.Main) { overlay?.setItems(items.toList()) }

    private fun id(t: String) = game + "|" + t.lowercase().replace(Regex("\\s+"), " ")

    private fun clean(x: String) = x.trim().trim(':', '.', ',', '!', '?', '-', '[', ']').lowercase()

    // Instant answer from glossary (fixed terms) or the UI-word dictionary; null if none.
    private fun quick(t: String): String? {
        val k = clean(t)
        return glossLc[k] ?: Glossary.ui[k]
    }

    // Decides if a text block is worth translating. Filters names, ping, IDs, kept terms.
    private fun worth(t: String): Boolean {
        if (t.length < 2 || t.none { it.isLetter() }) return false
        if (t.any { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }) return false
        if (t.count { it.isLetter() } < t.length / 2) return false
        val tokens = t.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.all { clean(it) in ignore }) return false
        val k = clean(t)
        if (glossLc.containsKey(k) && glossLc[k] == null) return false   // game name kept as-is
        if (quick(t) != null) return true                                 // dictionary word / fixed term
        if (skipSingle && tokens.size == 1) return false
        if (tokens.all { nameLike(it) }) return false
        return true
    }

    // mahdialkazaz-style names: digits mixed with letters, inner capitals (StReXpt), @handles
    private fun nameLike(w: String): Boolean =
        (w.any { it.isDigit() } && w.any { it.isLetter() }) ||
            Regex("[a-z][A-Z]").containsMatchIn(w) || w.startsWith("@")

    // Needs "Usage access" permission; without it everything goes to one shared "global" cache.
    private fun updateGame() {
        try {
            val um = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 15000, now)
            val e = UsageEvents.Event()
            var pkg: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) pkg = e.packageName
            }
            if (pkg != null && pkg != packageName) game = pkg
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        scope.cancel()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) { }
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        if (::recognizer.isInitialized) recognizer.close()
        super.onDestroy()
    }
}
