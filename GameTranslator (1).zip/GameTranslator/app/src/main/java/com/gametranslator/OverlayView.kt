package com.gametranslator

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

data class Item(val src: String, val box: Rect, var ar: String? = null)

/** Full-screen, non-touchable layer that paints Arabic boxes over the original text. */
class OverlayView(ctx: Context, var k: Float) : View(ctx) {
    private var items: List<Item> = emptyList()
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE14141C.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setItems(l: List<Item>) { items = l; invalidate() }

    override fun onDraw(c: Canvas) {
        for (it in items) {
            val ar = it.ar ?: continue
            val r = RectF(it.box.left * k, it.box.top * k, it.box.right * k, it.box.bottom * k)
            r.inset(-8f, -5f)
            c.drawRoundRect(r, 14f, 14f, bg)
            val w = max(r.width() - 16f, 60f).toInt()
            var size = min(r.height(), 60f)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(ar, 0, ar.length, tp, w)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                if (layout.height <= r.height() - 6f || size <= 18f) break
                size -= 2f
            }
            c.save()
            c.translate(r.left + 8f, r.top + (r.height() - layout.height) / 2f)
            layout.draw(c)
            c.restore()
        }
    }
}
